// src/EmployeeDashboard.js
import React, { useEffect, useState, useContext } from 'react';
import { db } from './firebase';
import {
  collection,
  doc,
  getDoc,
  onSnapshot,
  setDoc,
  updateDoc,
} from 'firebase/firestore';
import { AuthContext } from './AuthContext';
import './App.css';
import { useNavigate } from 'react-router-dom';

const EmployeeDashboard = () => {
  const { currentUser } = useContext(AuthContext);
  const [userData, setUserData] = useState(null);
  const navigate = useNavigate();

  useEffect(() => {
    if (!currentUser) return;

    const unsubscribe = onSnapshot(
      doc(db, 'users', currentUser.uid),
      (docSnap) => {
        if (docSnap.exists()) {
          setUserData(docSnap.data());
        }
      }
    );

    return () => unsubscribe();
  }, [currentUser]);

  const handleClockInOut = () => {
    navigate('/clock');
  };

  const handleLeave = () => {
    navigate('/leave');
  };

  if (!userData) return <div>Loading...</div>;

  return (
  <div className="main-wrapper">
    <div className="glass-card employee-card">
      <h2 className="title">Employee Dashboard</h2>
      <button className="button-primary" onClick={handleClockInOut}>Clock In / Out</button>
      <button className="button-primary" onClick={() => navigate('/leave-request')}>Request Leave</button>
      <button className="button-secondary" onClick={handleLogout}>Logout</button>
    </div>
  </div>
);

};

export default EmployeeDashboard;
