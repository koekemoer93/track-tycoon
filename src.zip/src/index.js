import React from 'react';
import ReactDOM from 'react-dom/client'; // ✅ React 18+ compatible import

// Import theme and global CSS
import './theme.css';
import './index.css';

import App from './App';
import * as serviceWorkerRegistration from './serviceWorkerRegistration';
import reportWebVitals from './reportWebVitals';
import { AuthProvider } from './AuthContext';

// ✅ Create root using React 18's method
const root = ReactDOM.createRoot(document.getElementById('root'));

root.render(
  <React.StrictMode>
    <AuthProvider>
      <App />
    </AuthProvider>
  </React.StrictMode>
);

// ✅ Keep service worker functionality
serviceWorkerRegistration.register();

// ✅ Keep performance reporting
reportWebVitals();
