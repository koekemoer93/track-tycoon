// src/App.js
import './theme.css';
import React from 'react';
import { BrowserRouter as Router, Routes, Route, useLocation } from 'react-router-dom';

import TrackDashboard from './TrackDashboard';
import TrackPage from './TrackPage';
import StockRoomPage from './StockRoomPage';
import StockImportPage from './StockImportPage';
import EmployeeDashboard from './EmployeeDashboard';
import AuthPage from './AuthPage';
import UserAdminPage from './UserAdminPage';
import TopNav from './components/TopNav';
import RoleRedirect from './RoleRedirect';
import UploadPage from './UploadPage';
import AdminRegisterUser from './AdminRegisterUser';
import ProtectedRoute from './components/ProtectedRoute';
import TaskHistory from './TaskHistory';
import ClockInPage from './ClockInPage';
import LeaveRequestPage from './LeaveRequestPage';
import LeaveTrackerPage from './LeaveTrackerPage';

// Wrapper component to access useLocation inside Router
const AppWrapper = () => {
  const location = useLocation();
  const isAuthPage = location.pathname === '/auth';

  return (
    <div className="page">
      <div className={isAuthPage ? '' : 'glass-card'}>
        {!isAuthPage && <TopNav />}

        <Routes>
          <Route path="/" element={<RoleRedirect />} />
          <Route path="/auth" element={<AuthPage />} />
          <Route path="/track-dashboard" element={
            <ProtectedRoute requireAdmin={true}>
              <TrackDashboard />
            </ProtectedRoute>
          } />
          <Route path="/stockroom" element={
            <ProtectedRoute requireAdmin={true}>
              <StockRoomPage />
            </ProtectedRoute>
          } />
          <Route path="/employee-dashboard" element={
            <ProtectedRoute>
              <EmployeeDashboard />
            </ProtectedRoute>
          } />
          <Route path="/task-history" element={<TaskHistory />} />
          <Route path="/admin-register" element={<AdminRegisterUser />} />
          <Route path="/upload" element={<UploadPage />} />
          <Route path="/dashboard" element={<TrackDashboard />} />
          <Route path="/import-stock" element={<StockImportPage />} />
          <Route path="/track/:trackId" element={<TrackPage />} />
          <Route path="/admin-panel" element={<UserAdminPage />} />
          <Route path="/leave" element={
            <ProtectedRoute>
              <LeaveRequestPage />
            </ProtectedRoute>
          } />
          <Route path="/clock-in" element={
            <ProtectedRoute>
              <ClockInPage />
            </ProtectedRoute>
          } />
          <Route path="/leave-tracker" element={
            <ProtectedRoute requireAdmin={true}>
              <LeaveTrackerPage />
            </ProtectedRoute>
          } />
        </Routes>

        {!isAuthPage && (
          <footer style={{ textAlign: 'center', padding: '10px' }}>
            <a
              className="App-link"
              href="https://reactjs.org"
              target="_blank"
              rel="noopener noreferrer"
            >
              Learn React
            </a>
          </footer>
        )}
      </div>
    </div>
  );
};

function App() {
  return (
    <Router>
      <AppWrapper />
    </Router>
  );
}

export default App;
